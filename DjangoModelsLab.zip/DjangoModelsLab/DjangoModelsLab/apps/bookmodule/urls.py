
from django.urls import path
from . import views

urlpatterns = [
    path('simple/query', views.simple_query, name='simple_query'),
    path('complex/query', views.lookup_query, name='complex_query'),
]
